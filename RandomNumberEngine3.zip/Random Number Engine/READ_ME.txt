Start the server by executing:
java bim.randomNumberEngine.server.MainServer <port number for server to listen>

Build random number servers by ManageServer.jar

Login to random number client and chat client by User.jar