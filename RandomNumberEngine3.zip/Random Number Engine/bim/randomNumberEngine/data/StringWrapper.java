package bim.randomNumberEngine.data;

class StringWrapper {
  volatile String strStr="";

  StringWrapper() {
  }

  StringWrapper(String strStr) {
    this.strStr=strStr;
  }

  public String getString() {
    return strStr;
  }

  public void setString(String strStr) {
    this.strStr=strStr;
  }
}