package bim.randomNumberEngine.data;

import java.io.Serializable;
import java.util.Vector;

public class RandomNumberObject extends Vector
implements Serializable {
  volatile String strLeafName="";
  volatile String strLeafDescription="";
  volatile Integer leafIndex=new Integer(0);


  volatile Boolean blnLeaf=new Boolean(false);
  volatile Double dblLeafMinimum=new Double(0.0d);
  volatile Double dblLeafMaximum=new Double(0.0d);

  public static int RANDOM_NUMBER_DOUBLE=0;
  public static int RANDOM_NUMBER_CEILING=1;
  public static int RANDOM_NUMBER_FLOOR=2;
  public static int RANDOM_NUMBER_ROUNDED=3;

  volatile Integer randomNumberType=new Integer(0);


//  RandomNumberObject rNOBranches=new RandomNumberObject();

  volatile Boolean blnRoot=new Boolean(false);
  volatile transient RandomNumberObject leafsBranch;

  public RandomNumberObject() {
    strLeafName="Root";
  }

  public RandomNumberObject(String strLeafName, String strLeafDescription) {
    this.strLeafName=strLeafName;
    this.strLeafDescription=strLeafDescription;
  }

  public RandomNumberObject(String strLeafName, String strLeafDescription, int leafIndex) {
    this.strLeafName=strLeafName;
    this.strLeafDescription=strLeafDescription;
    this.leafIndex=new Integer(leafIndex);
  }

  public String getLeafName() {
    return strLeafName;
  }

  public void setLeafName(String strLeafName) {
    this.strLeafName=strLeafName;
  }

  public String getLeafDescription() {
    return strLeafDescription;
  }

  public void setLeafDescription(String strLeafDescription) {
    this.strLeafDescription=strLeafDescription;
  }

  public int getLeafIndex() {
    return leafIndex.intValue();
  }

  public void setLeafIndex(int leafIndex) {
    this.leafIndex=new Integer(leafIndex);
  }

  public boolean isLeaf() {
    return blnLeaf.booleanValue();
  }

  public void setIsLeaf(boolean blnLeaf) {
    this.blnLeaf=new Boolean(blnLeaf);
  }

  public double getLeafMinimum() {
    return dblLeafMinimum.doubleValue();
  }

  public void setLeafMinimum(double dblLeafMinimum) {
    this.dblLeafMinimum=new Double(dblLeafMinimum);
  }

  public double getLeafMaximum() {
    return dblLeafMaximum.doubleValue();
  }

  public void setLeafMaximum(double dblLeafMaximum) {
    this.dblLeafMaximum=new Double(dblLeafMaximum);
  }

  public int getRandomNumberType() {
    return randomNumberType.intValue();
  }

  public void setRandomNumberType(int randomNumberType) {
    this.randomNumberType=new Integer(randomNumberType);
  }

  public boolean isRoot() {
    return blnRoot.booleanValue();
  }

  public void setIsRoot(boolean blnRoot) {
    this.blnRoot=new Boolean(blnRoot);
  }

  public RandomNumberObject getLeafsBranch() {
    return leafsBranch;
  }

  public void setLeafsBranch(RandomNumberObject leafsBranch) {
    this.leafsBranch=leafsBranch;
  }

  public double generateRandom() {
    double dblRandom=dblLeafMaximum.doubleValue()-dblLeafMinimum.doubleValue();
    dblRandom=dblRandom*Math.random();
    dblRandom+=dblLeafMinimum.doubleValue();

    if(randomNumberType.intValue()==RANDOM_NUMBER_CEILING)
      dblRandom=Math.ceil(dblRandom);
    else if(randomNumberType.intValue()==RANDOM_NUMBER_FLOOR)
      dblRandom=Math.floor(dblRandom);
    else if(randomNumberType.intValue()==RANDOM_NUMBER_ROUNDED)
      dblRandom=Math.rint(dblRandom);

    return dblRandom;
  }

  public static String exportToString(RandomNumberObject rNO) {
    return StringUtility.createBIMString(rNO);
  }

  public static RandomNumberObject importFromString(String strStr) {
    return StringUtility.createBIMRandomNumberObject(strStr);
  }

  public String toString() {
    StringBuffer sBuf=new StringBuffer();

    Vector vecPath=new Vector();

    RandomNumberObject rNO=this;

    while(true) {
      vecPath.addElement(rNO.getLeafName());
      if(blnRoot.booleanValue())
        break;

      rNO=leafsBranch;
    }

    for(int i=vecPath.size()-1;i>=0;i--)
      sBuf.append(String.valueOf(vecPath.elementAt(i))+"->");

    String strStr=sBuf.toString();

    sBuf=new StringBuffer();

    sBuf.append(strStr.substring(0, strStr.length()-2));

    if(blnLeaf.booleanValue()) {
      sBuf.append("\n\n");

      sBuf.append("Minimum = "+String.valueOf(dblLeafMinimum)+"\n");
      sBuf.append("Maximum = "+String.valueOf(dblLeafMaximum)+"\n");

      if(randomNumberType.intValue()==RANDOM_NUMBER_DOUBLE)
        sBuf.append("Exact");
      else if(randomNumberType.intValue()==RANDOM_NUMBER_CEILING)
        sBuf.append("Ceiling");
      else if(randomNumberType.intValue()==RANDOM_NUMBER_FLOOR)
        sBuf.append("Floor");
      else if(randomNumberType.intValue()==RANDOM_NUMBER_ROUNDED)
        sBuf.append("Rounded");
    }

    sBuf.append("\n\n");

    return sBuf.toString();
  }
}