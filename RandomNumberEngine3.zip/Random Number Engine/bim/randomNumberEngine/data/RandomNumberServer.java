package bim.randomNumberEngine.data;

import java.io.Serializable;

public class RandomNumberServer
implements Serializable {
  public static int MAXIMUM_SERVER_LENGTH=10000;

  volatile String strID="";
  volatile String strAdministrator="";
  volatile String strPassword="";
  volatile String strUserPassword="";

  volatile RandomNumberObject rNORoot=new RandomNumberObject();

  public RandomNumberServer(String strID, String strAdministrator, String strPassword, String strUserPassword) {
    this.strID=strID;
    this.strAdministrator=strAdministrator;
    this.strPassword=strPassword;
    this.strUserPassword=strUserPassword;
  }

  public String getID() {
    return strID;
  }

  public void setID(String strID) {
    this.strID=strID;
  }

  public String getAdministrator() {
    return strAdministrator;
  }

  public void setAdministrator(String strAdministrator) {
    this.strAdministrator=strAdministrator;
  }

  public String getPassword() {
    return strPassword;
  }

  public void setPassword(String strPassword) {
    this.strPassword=strPassword;
  }

  public String getUserPassword() {
    return strUserPassword;
  }

  public void setUserPassword(String strUserPassword) {
    this.strUserPassword=strUserPassword;
  }

  public RandomNumberObject getRoot() {
    return rNORoot;
  }

  public void setRoot(RandomNumberObject rNORoot) {
    this.rNORoot=rNORoot;
  }
}