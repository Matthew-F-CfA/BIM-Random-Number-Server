package bim.randomNumberEngine.data;

import bim.randomNumberEngine.server.RandomCommunicatorServerTransmitter;
import bim.randomNumberEngine.server.RandomCommunicatorServerReceiver;
import bim.randomNumberEngine.client.RandomCommunicatorClientTransmitter;
import bim.randomNumberEngine.client.RandomCommunicatorClientReceiver;


public class User {
  volatile String strUserName="";
  volatile String strUserPassword="";

  volatile boolean blnAdministrator=false;

  volatile RandomNumberObject rNORandoms=new RandomNumberObject();

  volatile RandomCommunicatorServerTransmitter rCST;
  volatile RandomCommunicatorServerReceiver rCSR;
  volatile RandomCommunicatorClientTransmitter rCCT;
  volatile RandomCommunicatorClientReceiver rCCR;

  public User(String strUserName, String strUserPassword) {
    this.strUserName=strUserName;
    this.strUserPassword=strUserPassword;
  }

  public String getUserName() {
    return strUserName;
  }

  public void setUserName(String strUserName) {
    this.strUserName=strUserName;
  }

  public String getUserPassword() {
    return strUserPassword;
  }

  public void setUserPassword(String strUserPassword) {
    this.strUserPassword=strUserPassword;
  }

  public boolean isAdministrator() {
    return blnAdministrator;
  }

  public void setIsAdministrator(boolean blnAdministrator) {
    this.blnAdministrator=blnAdministrator;
  }

  public RandomNumberObject getRandoms() {
    return rNORandoms;
  }

  public void setRandoms(RandomNumberObject rNORandoms) {
    this.rNORandoms=rNORandoms;
  }

  public RandomCommunicatorServerTransmitter getServerTransmitter() {
    return rCST;
  }

  public void setServerTransmitter(RandomCommunicatorServerTransmitter rCST) {
    this.rCST=rCST;
  }

  public RandomCommunicatorServerReceiver getServerReceiver() {
    return rCSR;
  }

  public void setServerReceiver(RandomCommunicatorServerReceiver rCSR) {
    this.rCSR=rCSR;
  }

  public RandomCommunicatorClientTransmitter getClientTransmitter() {
    return rCCT;
  }

  public void setClientTransmitter(RandomCommunicatorClientTransmitter rCCT) {
    this.rCCT=rCCT;
  }

  public RandomCommunicatorClientReceiver getClientReceiver() {
    return rCCR;
  }

  public void setClientReceiver(RandomCommunicatorClientReceiver rCCR) {
    this.rCCR=rCCR;
  }
}