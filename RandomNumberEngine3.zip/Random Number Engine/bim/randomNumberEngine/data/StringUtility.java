package bim.randomNumberEngine.data;

import java.util.Vector;

public class StringUtility {

  public static String createBIMString(String strStr) {
    int intLen=strStr.length();
    int intLenLen=String.valueOf(intLen).length();

    return String.valueOf(intLenLen)+String.valueOf(intLen)+strStr;
  }

  public static String createBIMString(Integer intInt) {
    return createBIMString(String.valueOf(intInt.intValue()));
  }

  public static String createBIMString(Boolean blnBln) {
    return createBIMString(String.valueOf(blnBln.booleanValue()));
  }
  
  public static String createBIMString(Double dblDbl) {
    return createBIMString(String.valueOf(dblDbl.doubleValue()));
  }

  public static String createBIMString(RandomNumberObject rNO) {
    StringBuffer sBuf=new StringBuffer();

    sBuf.append(createBIMString(rNO.strLeafName));
    sBuf.append(createBIMString(rNO.strLeafDescription));
    sBuf.append(createBIMString(rNO.leafIndex));
    sBuf.append(createBIMString(rNO.blnLeaf));
    sBuf.append(createBIMString(rNO.dblLeafMinimum));
    sBuf.append(createBIMString(rNO.dblLeafMaximum));
    sBuf.append(createBIMString(rNO.randomNumberType));

    sBuf.append(createBIMString(new Integer(rNO.size())));
    for(int i=0;i<rNO.size();i++)
      sBuf.append(createBIMString(((RandomNumberObject)rNO.elementAt(i))));

    sBuf.append(createBIMString(rNO.blnRoot));

    String strStr=sBuf.toString();
    int intLen=strStr.length();
    int intLenLen=String.valueOf(intLen).length();
    strStr=String.valueOf(intLenLen)+String.valueOf(intLen)+strStr;

    return strStr;
  }

  public static String[] readBIMString(String strStr) {
    int intLenLen=Integer.valueOf(strStr.substring(0, 1)).intValue();
    int intLen=Integer.valueOf(strStr.substring(1, 1+intLenLen)).intValue();
    String strRet=strStr.substring(1+intLenLen, 1+intLenLen+intLen);

    String strRetArr[]=new String[2];
    strRetArr[0]=strRet;
    strRetArr[1]=strStr.substring(1+intLenLen+intLen);

    return strRetArr;
  }

  public static RandomNumberObject createBIMRandomNumberObject(String strStr) {
    return createBIMRandomNumberObject(strStr, new StringWrapper());
  }

  public static RandomNumberObject createBIMRandomNumberObject(String strStr, StringWrapper strWrapperRet) {
    RandomNumberObject rNO=new RandomNumberObject();

    String strRNOA[]=readBIMString(strStr);
    String strRNO=strRNOA[0];
    strWrapperRet.setString(strRNOA[1]);

    strStr=strRNO;

    String strLeafNameArr[]=readBIMString(strStr);
    String strLeafName=strLeafNameArr[0];
    strStr=strLeafNameArr[1];
    rNO.setLeafName(strLeafName);

    String strLeafDescriptionArr[]=readBIMString(strStr);
    String strLeafDescription=strLeafDescriptionArr[0];
    strStr=strLeafDescriptionArr[1];
    rNO.setLeafDescription(strLeafDescription);

    String strLeafIndexArr[]=readBIMString(strStr);
    int leafIndex=Integer.parseInt(strLeafIndexArr[0]);
    strStr=strLeafIndexArr[1];
    rNO.setLeafIndex(leafIndex);

    String strLeafArr[]=readBIMString(strStr);
    boolean blnLeaf=Boolean.valueOf(strLeafArr[0]).booleanValue();
    strStr=strLeafArr[1];
    rNO.setIsLeaf(blnLeaf);

    String strLeafMinimumArr[]=readBIMString(strStr);
    double dblLeafMinimum=Double.valueOf(strLeafMinimumArr[0]).doubleValue();
    strStr=strLeafMinimumArr[1];
    rNO.setLeafMinimum(dblLeafMinimum);

    String strLeafMaximumArr[]=readBIMString(strStr);
    double dblLeafMaximum=Double.valueOf(strLeafMaximumArr[0]).doubleValue();
    strStr=strLeafMaximumArr[1];
    rNO.setLeafMaximum(dblLeafMaximum);

    String strRandomNumberTypeArr[]=readBIMString(strStr);
    int intRandomNumberType=Integer.parseInt(strRandomNumberTypeArr[0]);
    strStr=strRandomNumberTypeArr[1];
    rNO.setRandomNumberType(intRandomNumberType);

    String strBranchesSizeArr[]=readBIMString(strStr);
    int intBranchesSize=Integer.parseInt(strBranchesSizeArr[0]);
    strStr=strBranchesSizeArr[1];

//    RandomNumberObject vecBranches=new RandomNumberObject();

    for(int i=0;i<intBranchesSize;i++) {
      StringWrapper strWrapper=new StringWrapper();
      RandomNumberObject nextRNO=createBIMRandomNumberObject(strStr, strWrapper);

      rNO.addElement(nextRNO);
//      vecBranches.addElement(nextRNO);
      strStr=strWrapper.getString();
    }

//    rNO=vecBranches;

    String strRootArr[]=readBIMString(strStr);
    boolean blnRoot=Boolean.valueOf(strRootArr[0]).booleanValue();
    strStr=strRootArr[1];
    rNO.setIsRoot(blnRoot);

//    strWrapperRet.setString(strStr);

    return rNO;
  }
}