package bim.randomNumberEngine.client;

import bim.randomNumberEngine.data.RandomNumberObject;
import bim.randomNumberEngine.data.StringUtility;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.net.Socket;
import java.io.*;


public class ManageServerFrame extends Frame
implements ActionListener {
  List lstTree=new List(5);
  Label lblTreePath=new Label("                                                                                                                                           ");
  Button btnAscend=new Button("Ascend");
  Button btnDescend=new Button("Descend");
  Button btnAddBranch=new Button("Add Branch");
  Button btnRemoveBranch=new Button("Remove Branch");
  Button btnBranchDetails=new Button("Branch Details");

  Button btnLoadServer=new Button("Load Server");
  Button btnCreateNewServer=new Button("Create New Server");
  Button btnCopyServer=new Button("Copy Server");
  Button btnDeleteServer=new Button("Delete Server");

  Label lblStatus=new Label("Status:                                                                                                                                     ");

  RandomNumberObject rNO=new RandomNumberObject();

  public static void main(String args[]) {
    ManageServerFrame mFrame=new ManageServerFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);
  }

  public ManageServerFrame() {
    super("New Server Frame");

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

//    lstTree.add(rNO.getLeafName());

    rNO.setIsRoot(true);

    lblTreePath.setText(rNO.getLeafName());

    Panel pnlTempZ=new Panel();
    pnlTempZ.setLayout(new BorderLayout());
    pnlTempZ.add("West", new Label("Tree Path:"));
    pnlTempZ.add("Center", lblTreePath);
    add("North", pnlTempZ);

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new BorderLayout());
    pnlTemp.add("North", new Label("Random Tree"));
    pnlTemp.add("West", btnDescend);
    btnDescend.addActionListener(this);
    pnlTemp.add("East", btnAscend);
    btnAscend.addActionListener(this);
    pnlTemp.add("Center", lstTree);
    Panel pnlTempA=new Panel();
    pnlTempA.setLayout(new GridLayout(3, 1));
    pnlTempA.add(btnAddBranch);
    btnAddBranch.addActionListener(this);
    pnlTempA.add(btnRemoveBranch);
    btnRemoveBranch.addActionListener(this);
    pnlTempA.add(btnBranchDetails);
    btnBranchDetails.addActionListener(this);
    pnlTemp.add("South", pnlTempA);
    add("Center", pnlTemp);

    Panel pnlTemp2Z=new Panel();
    pnlTemp2Z.setLayout(new GridLayout(2, 1));
    Panel pnlTemp2=new Panel();
    pnlTemp2.add(btnLoadServer);
    btnLoadServer.addActionListener(this);
    pnlTemp2.add(btnCreateNewServer);
    btnCreateNewServer.addActionListener(this);
    pnlTemp2.add(btnCopyServer);
    btnCopyServer.addActionListener(this);
    pnlTemp2.add(btnDeleteServer);
    btnDeleteServer.addActionListener(this);
    pnlTemp2Z.add(pnlTemp2);
    pnlTemp2Z.add(lblStatus);
    add("South", pnlTemp2Z);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnAscend) {
      int intIndex=lstTree.getSelectedIndex();
      if(intIndex==-1)
        return;

      rNO=(RandomNumberObject)rNO.elementAt(intIndex);

      lstTree.removeAll();
      for(int i=0;i<rNO.size();i++) {
        RandomNumberObject nextRNO=(RandomNumberObject)rNO.elementAt(i);
        lstTree.add(nextRNO.getLeafName());
      }

      String strTreePath=lblTreePath.getText();

      strTreePath=strTreePath+"/"+rNO.getLeafName();

      lblTreePath.setText(strTreePath);
    }
    else if(evSource==btnDescend) {
      if(rNO.isRoot())
        return;

      rNO=rNO.getLeafsBranch();

      lstTree.removeAll();
      for(int i=0;i<rNO.size();i++) {
        RandomNumberObject nextRNO=(RandomNumberObject)rNO.elementAt(i);
        lstTree.add(nextRNO.getLeafName());
      }

      String strTreePath=lblTreePath.getText();

      int intSlashIndex=strTreePath.lastIndexOf("/");

      strTreePath=strTreePath.substring(0, intSlashIndex);

      lblTreePath.setText(strTreePath);
    }
    else if(evSource==btnAddBranch) {
//      int intIndex=lstTree.getSelectedIndex();

//      if(intIndex==-1)
//        return;

/*
      if(intIndex==-1) {
        if(rNO==null)
          return;

        intIndex=0;
      }
*/

      AddBranchDialog aDialog=new AddBranchDialog(this, "Add Branch Dialog");
      aDialog.show();

      if(aDialog.cancelIt())
        return;

      RandomNumberObject addRNO=aDialog.getNewBranch();

      addRNO.setLeafIndex(lstTree.getItemCount());

      rNO.addElement(addRNO);

/*
      addRNO.setLeafIndex(intIndex);
      for(int i=intIndex;i<rNO.size();i++)
        ((RandomNumberObject)rNO.elementAt(i)).setLeafIndex(i+1);

      rNO.insertElementAt(addRNO, intIndex);
*/

      addRNO.setLeafsBranch(rNO);

      lstTree.add(addRNO.getLeafName());
    }
    else if(evSource==btnRemoveBranch) {
      int intIndex=lstTree.getSelectedIndex();
      if(intIndex==-1)
        return;

      ConfirmDialog cDialog=new ConfirmDialog(this, "Remove Branch Dialog", "Are you sure you want to delete branch \""+lstTree.getItem(intIndex)+"\"?");
      cDialog.show();

      if(cDialog.didConfirm()) {
        lstTree.remove(intIndex);
        rNO.removeElementAt(intIndex);

        for(int i=intIndex;i<rNO.size();i++)
          ((RandomNumberObject)rNO.elementAt(i)).setLeafIndex(i);
      }
    }
    else if(evSource==btnBranchDetails) {
      int intIndex=lstTree.getSelectedIndex();
      if(intIndex==-1)
        return;

      AddBranchDialog aDialog=new AddBranchDialog(this, "Add Branch Dialog", (RandomNumberObject)rNO.elementAt(intIndex));
      aDialog.show();

      if(aDialog.cancelIt())
        return;

      RandomNumberObject addRNO=aDialog.getNewBranch();

      addRNO.setLeafIndex(intIndex);

      rNO.setElementAt(addRNO, intIndex);

      addRNO.setLeafsBranch(rNO);
    }
    else if(evSource==btnLoadServer) {
      ConfirmDialog cDialog=new ConfirmDialog(this, "Confirm Load Dialog", "Attempt to load server? You will lose all unsaved work.");
      cDialog.show();

      if(cDialog.didConfirm()) {
        LoadServerDialog lDialog=new LoadServerDialog(this, "Load Server Dialog");
        lDialog.show();

        if(lDialog.cancelIt())
          return;

        rNO=lDialog.getLoadedRandoms();

        rNO.setIsRoot(true);

        lstTree.removeAll();
        for(int i=0;i<rNO.size();i++)
          lstTree.add(((RandomNumberObject)rNO.elementAt(i)).getLeafName());
      }
    }
    else if(evSource==btnCreateNewServer) {
      if(rNO==null)
        return;

      RandomNumberObject rRoot=rNO;

      while(true) {
        if(rRoot.isRoot())
          break;

        rRoot=rRoot.getLeafsBranch();
      }

      CreateNewServerDialog cDialog=new CreateNewServerDialog(this, "Create New Server Dialog", rRoot);
      cDialog.show();
    }
    else if(evSource==btnCopyServer) {
      CopyServerDialog cDialog=new CopyServerDialog(this, "Copy Server Dialog");
      cDialog.show();
    }
    else if(evSource==btnDeleteServer) {
      DeleteServerDialog dDialog=new DeleteServerDialog(this, "Delete Server Dialog");
      dDialog.show();
    }
  }

  class AddBranchDialog extends Dialog
  implements ActionListener, ItemListener {
    TextField tfBranchName=new TextField(50);
    TextArea txtBranchDescription=new TextArea(5, 50);
    Checkbox chbHasRandom=new Checkbox("Has Random?", false);
    TextField tfRandomMinimum=new TextField(10);
    TextField tfRandomMaximum=new TextField(10);
    CheckboxGroup cbgRandomNumberType=new CheckboxGroup();
    Checkbox chbExact=new Checkbox("Exact", cbgRandomNumberType, false);
    Checkbox chbCeiling=new Checkbox("Ceiling", cbgRandomNumberType, false);
    Checkbox chbFloor=new Checkbox("Floor", cbgRandomNumberType, false);
    Checkbox chbRounded=new Checkbox("Integer", cbgRandomNumberType, true);

    Button btnAdd=new Button("Add Branch");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    RandomNumberObject rNONewBranch;

    AddBranchDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      tfRandomMinimum.setEnabled(false);
      tfRandomMaximum.setEnabled(false);
      chbExact.setEnabled(false);
      chbCeiling.setEnabled(false);
      chbFloor.setEnabled(false);
      chbRounded.setEnabled(false);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new BorderLayout());
      pnlTemp.add("West", new Label("Branch Name: "));
      pnlTemp.add("Center", tfBranchName);
      add("North", pnlTemp);
      add("Center", txtBranchDescription);

      Panel pnlTemp2=new Panel();
      pnlTemp2.setLayout(new GridLayout(6, 1));
      pnlTemp2.add(new Label(""));
      pnlTemp2.add(chbHasRandom);
      chbHasRandom.addItemListener(this);
      Panel pnlTemp2A=new Panel();
      pnlTemp2A.setLayout(new BorderLayout());
      pnlTemp2A.add("West", new Label("Random Minimum: "));
      pnlTemp2A.add("Center", tfRandomMinimum);
      pnlTemp2.add(pnlTemp2A);
      Panel pnlTemp2B=new Panel();
      pnlTemp2B.setLayout(new BorderLayout());
      pnlTemp2B.add("West", new Label("Random Maximum: "));
      pnlTemp2B.add("Center", tfRandomMaximum);
      pnlTemp2.add(pnlTemp2B);
      Panel pnlTemp2C=new Panel();
      pnlTemp2C.setLayout(new GridLayout(1, 4));
      pnlTemp2C.add(chbExact);
      pnlTemp2C.add(chbCeiling);
      pnlTemp2C.add(chbFloor);
      pnlTemp2C.add(chbRounded);
      pnlTemp2.add(pnlTemp2C);
      Panel pnlTemp2D=new Panel();
      pnlTemp2D.add(btnAdd);
      btnAdd.addActionListener(this);
      pnlTemp2D.add(btnCancel);
      btnCancel.addActionListener(this);
      pnlTemp2.add(pnlTemp2D);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    AddBranchDialog(Frame parent, String strTitle, RandomNumberObject rNOExisting) {
      super(parent, strTitle, true);

      tfBranchName.setText(rNOExisting.getLeafName());
      txtBranchDescription.setText(rNOExisting.getLeafDescription());

      if(rNOExisting.isLeaf()) {
        tfRandomMinimum.setEnabled(true);
        tfRandomMaximum.setEnabled(true);
        chbExact.setEnabled(true);
        chbCeiling.setEnabled(true);
        chbFloor.setEnabled(true);
        chbRounded.setEnabled(true);

        tfRandomMinimum.setText(String.valueOf(rNOExisting.getLeafMinimum()));
        tfRandomMaximum.setText(String.valueOf(rNOExisting.getLeafMaximum()));

        int intRandomNumberType=rNOExisting.getRandomNumberType();
        if(intRandomNumberType==RandomNumberObject.RANDOM_NUMBER_DOUBLE)
          chbExact.setState(true);
        if(intRandomNumberType==RandomNumberObject.RANDOM_NUMBER_CEILING)
          chbCeiling.setState(true);
        if(intRandomNumberType==RandomNumberObject.RANDOM_NUMBER_FLOOR)
          chbFloor.setState(true);
        if(intRandomNumberType==RandomNumberObject.RANDOM_NUMBER_ROUNDED)
          chbRounded.setState(true);
      }
      else {
        tfRandomMinimum.setEnabled(false);
        tfRandomMaximum.setEnabled(false);
        chbExact.setEnabled(false);
        chbCeiling.setEnabled(false);
        chbFloor.setEnabled(false);
        chbRounded.setEnabled(false);
      }

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new BorderLayout());
      pnlTemp.add("West", new Label("Branch Name: "));
      pnlTemp.add("Center", tfBranchName);
      add("North", pnlTemp);
      add("Center", txtBranchDescription);

      Panel pnlTemp2=new Panel();
      pnlTemp2.setLayout(new GridLayout(6, 1));
      pnlTemp2.add(new Label(""));
      pnlTemp2.add(chbHasRandom);
      chbHasRandom.addItemListener(this);
      Panel pnlTemp2A=new Panel();
      pnlTemp2A.setLayout(new BorderLayout());
      pnlTemp2A.add("West", new Label("Random Minimum: "));
      pnlTemp2A.add("Center", tfRandomMinimum);
      pnlTemp2.add(pnlTemp2A);
      Panel pnlTemp2B=new Panel();
      pnlTemp2B.setLayout(new BorderLayout());
      pnlTemp2B.add("West", new Label("Random Maximum: "));
      pnlTemp2B.add("Center", tfRandomMaximum);
      pnlTemp2.add(pnlTemp2B);
      Panel pnlTemp2C=new Panel();
      pnlTemp2C.setLayout(new GridLayout(1, 4));
      pnlTemp2C.add(chbExact);
      pnlTemp2C.add(chbCeiling);
      pnlTemp2C.add(chbFloor);
      pnlTemp2C.add(chbRounded);
      pnlTemp2.add(pnlTemp2C);
      Panel pnlTemp2D=new Panel();
      pnlTemp2D.add(btnAdd);
      btnAdd.addActionListener(this);
      pnlTemp2D.add(btnCancel);
      btnCancel.addActionListener(this);
      pnlTemp2.add(pnlTemp2D);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public boolean cancelIt() {
      return cancelIt;
    }

    public RandomNumberObject getNewBranch() {
      return rNONewBranch;
    }

    public void itemStateChanged(ItemEvent ie) {
      if(chbHasRandom.getState()) {
        tfRandomMinimum.setEnabled(true);
        tfRandomMaximum.setEnabled(true);
        chbExact.setEnabled(true);
        chbCeiling.setEnabled(true);
        chbFloor.setEnabled(true);
        chbRounded.setEnabled(true);
      }
      else {
        tfRandomMinimum.setEnabled(false);
        tfRandomMaximum.setEnabled(false);
        chbExact.setEnabled(false);
        chbCeiling.setEnabled(false);
        chbFloor.setEnabled(false);
        chbRounded.setEnabled(false);
      }
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAdd) {
        String strBranchName=tfBranchName.getText();
        if(strBranchName.length()==0)
          return;

        if(strBranchName.indexOf("/")!=-1) {
          tfBranchName.setText("Error. \"/\" is an illegal character.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          tfBranchName.setText(strBranchName);

          return;
        }

        String strBranchDescription=txtBranchDescription.getText();

        rNONewBranch=new RandomNumberObject(strBranchName, strBranchDescription);

        if(chbHasRandom.getState()) {
          String strRandomMinimum=tfRandomMinimum.getText();
          if(strRandomMinimum.length()==0)
            return;
          double dblRandomMinimum=0.0d;
          try {
            dblRandomMinimum=Double.valueOf(strRandomMinimum).doubleValue();
          }
          catch(Exception ex) {
            return;
          }

          String strRandomMaximum=tfRandomMaximum.getText();
          if(strRandomMaximum.length()==0)
            return;
          double dblRandomMaximum=0.0d;
          try {
            dblRandomMaximum=Double.valueOf(strRandomMaximum).doubleValue();
          }
          catch(Exception ex) {
            return;
          }

          if(dblRandomMaximum<=dblRandomMinimum)
            return;

          rNONewBranch.setIsLeaf(true);
          rNONewBranch.setLeafMinimum(dblRandomMinimum);
          rNONewBranch.setLeafMaximum(dblRandomMaximum);

          if(chbExact.getState())
            rNONewBranch.setRandomNumberType(RandomNumberObject.RANDOM_NUMBER_DOUBLE);
          else if(chbCeiling.getState())
            rNONewBranch.setRandomNumberType(RandomNumberObject.RANDOM_NUMBER_CEILING);
          else if(chbFloor.getState())
            rNONewBranch.setRandomNumberType(RandomNumberObject.RANDOM_NUMBER_FLOOR);
          else if(chbRounded.getState())
            rNONewBranch.setRandomNumberType(RandomNumberObject.RANDOM_NUMBER_ROUNDED);
        }

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }
  }

  class LoadServerDialog extends Dialog
  implements ActionListener {
    TextField tfServerName=new TextField();
    TextField tfServerPort=new TextField();
    TextField tfID=new TextField();
    TextField tfAdmin=new TextField();
    TextField tfPassword=new TextField();

    Button btnLoad=new Button("Load Server");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    RandomNumberObject loadedRandoms;

    LoadServerDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(5, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);
      pnlTemp.add(new Label("ID: "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("Administrator Name: "));
      pnlTemp.add(tfAdmin);
      pnlTemp.add(new Label("Password: "));
      pnlTemp.add(tfPassword);
      add("North", pnlTemp);
      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnLoad);
      btnLoad.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public boolean cancelIt() {
      return cancelIt;
    }

    public RandomNumberObject getLoadedRandoms() {
      return loadedRandoms;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnLoad) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strAdmin=tfAdmin.getText();
        if(strAdmin.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;

        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="Load Server";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strAdmin.length());
          dos.writeBytes(strAdmin);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();

          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          if(!strResponse.equals("Success")) {
            lblStatus.setText("Status: "+strResponse);

            try {
              socket.close();
            }
            catch(Exception ex) {
            }

            return;
          }

          intLen=dis.readInt();
          bbuf=new byte[intLen];
          dis.readFully(bbuf);
          strResponse=new String(bbuf);

          loadedRandoms=StringUtility.createBIMRandomNumberObject(strResponse);

          referenceBranches(loadedRandoms);

          cancelIt=false;

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }

    public void referenceBranches(RandomNumberObject rBranch) {
      for(int i=0;i<rBranch.size();i++) {
        RandomNumberObject rLeaf=(RandomNumberObject)rBranch.elementAt(i);
        rLeaf.setLeafsBranch(rBranch);

        referenceBranches(rLeaf);
      }
    }
  }

  class CreateNewServerDialog extends Dialog
  implements ActionListener {
    TextField tfServerName=new TextField();
    TextField tfServerPort=new TextField();
    TextField tfID=new TextField();
    TextField tfAdmin=new TextField();
    TextField tfPassword=new TextField();
    TextField tfUserPassword=new TextField();

    Button btnCreateServer=new Button("Create Server");
    Button btnCancel=new Button("Cancel");

    RandomNumberObject rTree;

    CreateNewServerDialog(Frame parent, String strTitle, RandomNumberObject rTree) {
      super(parent, strTitle, true);

      this.rTree=rTree;

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(6, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);
      pnlTemp.add(new Label("ID : "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("Administrator: "));
      pnlTemp.add(tfAdmin);
      pnlTemp.add(new Label("Administrator Password: "));
      pnlTemp.add(tfPassword);
      pnlTemp.add(new Label("User Password: "));
      pnlTemp.add(tfUserPassword);
      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnCreateServer);
      btnCreateServer.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnCreateServer) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strAdmin=tfAdmin.getText();
        if(strAdmin.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;

        String strUserPassword=tfUserPassword.getText();
        if(strUserPassword.length()==0)
          return;

        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="New Server";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strAdmin.length());
          dos.writeBytes(strAdmin);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();

          dos.writeInt(strUserPassword.length());
          dos.writeBytes(strUserPassword);
          dos.flush();

          String strStr=StringUtility.createBIMString(rTree);
          dos.writeInt(strStr.length());
          dos.writeBytes(strStr);
          dos.flush();


          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          lblStatus.setText("Status: "+strResponse);

          try {
            socket.close();
          }
          catch(Exception ex) {
          }

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }

  class CopyServerDialog extends Dialog
  implements ActionListener {
    TextField tfServerName=new TextField();
    TextField tfServerPort=new TextField();
    TextField tfID=new TextField();
    TextField tfAdmin=new TextField();
    TextField tfPassword=new TextField();

    TextField tfID2=new TextField();
    TextField tfAdmin2=new TextField();
    TextField tfPassword2=new TextField();
    TextField tfUserPassword2=new TextField();

    Button btnCopyServer=new Button("Copy Server");
    Button btnCancel=new Button("Cancel");

    CopyServerDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(11, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);

      pnlTemp.add(new Label("Copy From"));
      pnlTemp.add(new Label(""));
      pnlTemp.add(new Label("ID : "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("Administrator: "));
      pnlTemp.add(tfAdmin);
      pnlTemp.add(new Label("Administrator Password: "));
      pnlTemp.add(tfPassword);

      pnlTemp.add(new Label("Copy To"));
      pnlTemp.add(new Label(""));
      pnlTemp.add(new Label("ID : "));
      pnlTemp.add(tfID2);
      pnlTemp.add(new Label("Administrator: "));
      pnlTemp.add(tfAdmin2);
      pnlTemp.add(new Label("Administrator Password: "));
      pnlTemp.add(tfPassword2);
      pnlTemp.add(new Label("User Password: "));
      pnlTemp.add(tfUserPassword2);


      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnCopyServer);
      btnCopyServer.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnCopyServer) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strAdmin=tfAdmin.getText();
        if(strAdmin.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;


        String strID2=tfID2.getText();
        if(strID2.length()==0)
          return;

        for(int i=0;i<strID2.length();i++) {
          char chrNext=strID2.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID2.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID2.setText(strID2);

            return;
          }
        }

        String strAdmin2=tfAdmin2.getText();
        if(strAdmin2.length()==0)
          return;

        String strPassword2=tfPassword2.getText();
        if(strPassword2.length()==0)
          return;

        String strUserPassword2=tfUserPassword2.getText();
        if(strUserPassword2.length()==0)
          return;


        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="Copy Server";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strAdmin.length());
          dos.writeBytes(strAdmin);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();


          dos.writeInt(strID2.length());
          dos.writeBytes(strID2);
          dos.flush();

          dos.writeInt(strAdmin2.length());
          dos.writeBytes(strAdmin2);
          dos.flush();

          dos.writeInt(strPassword2.length());
          dos.writeBytes(strPassword2);
          dos.flush();

          dos.writeInt(strUserPassword2.length());
          dos.writeBytes(strUserPassword2);
          dos.flush();


          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          lblStatus.setText("Status: "+strResponse);

          try {
            socket.close();
          }
          catch(Exception ex) {
          }

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }

  class DeleteServerDialog extends Dialog
  implements ActionListener {
    TextField tfServerName=new TextField();
    TextField tfServerPort=new TextField();
    TextField tfID=new TextField();
    TextField tfAdmin=new TextField();
    TextField tfPassword=new TextField();

    Button btnDeleteServer=new Button("Delete Server");
    Button btnCancel=new Button("Cancel");

    DeleteServerDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(5, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);

      pnlTemp.add(new Label("ID : "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("Administrator: "));
      pnlTemp.add(tfAdmin);
      pnlTemp.add(new Label("Administrator Password: "));
      pnlTemp.add(tfPassword);

      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnDeleteServer);
      btnDeleteServer.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnDeleteServer) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strAdmin=tfAdmin.getText();
        if(strAdmin.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;


        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="Delete Server";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strAdmin.length());
          dos.writeBytes(strAdmin);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();


          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          lblStatus.setText("Status: "+strResponse);

          try {
            socket.close();
          }
          catch(Exception ex) {
          }

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }

  class ConfirmDialog extends Dialog
  implements ActionListener {
    Button btnConfirm=new Button("Confirm");
    Button btnCancel=new Button("Cancel");
    boolean confirmed=false;

    ConfirmDialog(Frame parent, String strTitle, String strQuestion) {
      super(parent, strTitle, true);

      add("North", new Label(strQuestion));

      add("Center", new Label(""));

      Panel pnlTemp=new Panel();
      pnlTemp.add(btnConfirm);
      btnConfirm.addActionListener(this);
      pnlTemp.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", pnlTemp);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public boolean didConfirm() { 
      return confirmed;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnConfirm) {
        confirmed=true;

        dispose();
      }
      else if(evSource==btnCancel) {
        confirmed=false;

        dispose();
      }
    }
  }
}