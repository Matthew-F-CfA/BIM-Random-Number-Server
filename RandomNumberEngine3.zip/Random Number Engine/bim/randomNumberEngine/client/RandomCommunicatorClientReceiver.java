package bim.randomNumberEngine.client;

import bim.randomNumberEngine.data.User;
import bim.randomNumberEngine.data.RandomNumberObject;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.io.*;
import java.awt.TextArea;

public class RandomCommunicatorClientReceiver extends Thread {
  public static int GENERATE_RANDOM=0;
  public static int CHAT_MESSAGE=1;

  volatile boolean keepAlive=true;

  volatile Socket clientSocket;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;

  volatile User user;

  volatile TextArea txtMessageArea;


  public RandomCommunicatorClientReceiver(Socket clientSocket, DataInputStream dis, DataOutputStream dos, User user) {
    this.clientSocket=clientSocket;
    this.dis=dis;
    this.dos=dos;
    this.user=user;
  }

  public Socket getSocket() {
    return clientSocket;
  }

  public void setSocket(Socket clientSocket) {
    this.clientSocket=clientSocket;
  }

  public DataInputStream getInputStream() {
    return dis;
  }

  public void setInputStream(DataInputStream dis) {
    this.dis=dis;
  }

  public DataOutputStream getOutputStream() {
    return dos;
  }

  public void setOutputStream(DataOutputStream dos) {
    this.dos=dos;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user=user;
  }

  public TextArea getMessageArea() {
    return txtMessageArea;
  }

  public void setMessageArea(TextArea txtMessageArea) {
    this.txtMessageArea=txtMessageArea;
  }

  public void run() {
    try {
      while(keepAlive) {
        int intCode=dis.readInt();

        if(intCode==GENERATE_RANDOM) {
          int intMessageLen=dis.readInt();
          byte bbuf[]=new byte[intMessageLen];
          dis.readFully(bbuf);
          String strMessage=new String(bbuf);

          txtMessageArea.append(strMessage+"\n\n");
        }
        else if(intCode==CHAT_MESSAGE) {
          int intMessageLen=dis.readInt();
          byte bbuf[]=new byte[intMessageLen];
          dis.readFully(bbuf);
          String strMessage=new String(bbuf);

          txtMessageArea.append(strMessage+"\n\n");
        }
      }
    }
    catch(Exception ex) {
      if((ex instanceof SocketException) || (ex instanceof EOFException)) {
        txtMessageArea.append("Connection closed.\n\n");
      }
      else {
        ex.printStackTrace();
      }
    }

    try {
      clientSocket.close();
    }
    catch(Exception ex) {
    }
  }
}