package bim.randomNumberEngine.client;

import bim.randomNumberEngine.server.SingleServer;
import bim.randomNumberEngine.server.RandomCommunicatorServerReceiver;
import bim.randomNumberEngine.data.RandomNumberObject;
import bim.randomNumberEngine.data.User;
import bim.randomNumberEngine.data.StringUtility;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.Vector;

public class UserFrame extends Frame
implements ActionListener {
  volatile TextArea txtMain=new TextArea();
  volatile TextField tfChat=new TextField();
  volatile Button btnSendChat=new Button("Send");

  volatile Menu mnuLogin=new Menu("Login");
  volatile MenuItem mnuLoginAdmin=new MenuItem("Administrator");
  volatile MenuItem mnuLoginUser=new MenuItem("User");
  volatile MenuItem mnuLoginServerList=new MenuItem("Server List");
  volatile MenuItem mnuLoginLogout=new MenuItem("Logout");

  volatile Menu mnuRandom=new Menu("Random");
  volatile MenuItem mnuRandomGenerate=new MenuItem("Generate Random");

  volatile RandomNumberObject rNO;

  volatile User user;

  volatile RandomCommunicatorClientReceiver rCCR;
  volatile RandomCommunicatorClientTransmitter rCCT;

  public static void main(String args[]) {
    UserFrame uFrame=new UserFrame();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    uFrame.setSize(dimScreen.width, dimScreen.height-50);
    uFrame.setVisible(true);
  }

  public UserFrame() {
    super("User Frame");

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("Center", txtMain);
    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new BorderLayout());
    pnlTemp.add("West", new Label("Message:"));
    pnlTemp.add("Center", tfChat);
    pnlTemp.add("East", btnSendChat);
    btnSendChat.addActionListener(this);
    add("South", pnlTemp);

    mnuLogin.add(mnuLoginAdmin);
    mnuLoginAdmin.addActionListener(this);
    mnuLogin.add(mnuLoginUser);
    mnuLoginUser.addActionListener(this);
    mnuLogin.add(mnuLoginServerList);
    mnuLoginServerList.addActionListener(this);
    mnuLogin.add(mnuLoginLogout);
    mnuLoginLogout.addActionListener(this);

    mnuRandom.add(mnuRandomGenerate);
    mnuRandomGenerate.addActionListener(this);

    MenuBar mBar=new MenuBar();

    mBar.add(mnuLogin);
    mBar.add(mnuRandom);

    setMenuBar(mBar);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnSendChat) {
      if(user==null)
        return;

      String strChat=tfChat.getText();
      if(strChat.length()==0)
        return;

      try {
        user.getClientTransmitter().dos.writeInt(RandomCommunicatorServerReceiver.CHAT_MESSAGE);
        user.getClientTransmitter().dos.writeInt(strChat.length());
        user.getClientTransmitter().dos.writeBytes(strChat);
        user.getClientTransmitter().dos.flush();

        tfChat.setText("");
      }
      catch(Exception ex) {
      }
    }
    else if(evSource==mnuLoginAdmin) {
      logout();

      LoginAdminDialog lDialog=new LoginAdminDialog(this, "Login Administrator");
      lDialog.show();
    }
    else if(evSource==mnuLoginUser) {
      logout();

      LoginUserDialog lDialog=new LoginUserDialog(this, "Login User");
      lDialog.show();
    }
    else if(evSource==mnuLoginServerList) {
      ServerListDialog sDialog=new ServerListDialog(this, "Server List");
      sDialog.show();
    }
    else if(evSource==mnuLoginLogout) {
      logout();

      txtMain.append("Logged out.\n\n");
    }
    else if(evSource==mnuRandomGenerate) {
      if(user==null)
        return;

      RandomGenerateDialog rDialog=new RandomGenerateDialog(this, "Random Generate Dialog");
      rDialog.show();
    }
  }

  public void logout() {
    if(rCCR!=null) {
      rCCR.keepAlive=false;

      try {
        rCCR.getSocket().close();
      }
      catch(Exception ex) {
      }
    }

    rNO=null;
    user=null;
  }

  public static void referenceBranches(RandomNumberObject rBranch) {
    for(int i=0;i<rBranch.size();i++) {
      RandomNumberObject rLeaf=(RandomNumberObject)rBranch.elementAt(i);
      rLeaf.setLeafsBranch(rBranch);

      UserFrame.referenceBranches(rLeaf);
    }
  }

  class ServerListDialog extends Dialog
  implements ActionListener {
    volatile TextField tfServerName=new TextField();
    volatile TextField tfServerPort=new TextField();
    volatile List lstServers=new List(5);

    volatile Button btnGetServerList=new Button("Get Server List");
    volatile Button btnClose=new Button("Close");

    ServerListDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(2, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);

      add("North", pnlTemp);

      add("Center", lstServers);

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnGetServerList);
      btnGetServerList.addActionListener(this);
      pnlTemp2.add(btnClose);
      btnClose.addActionListener(this);

      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnGetServerList) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }


        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="List Servers";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();


          lstServers.removeAll();

          int intServerCount=dis.readInt();

          for(int i=0;i<intServerCount;i++) {
            int intLen=dis.readInt();
            byte bbuf[]=new byte[intLen];
            dis.readFully(bbuf);
            String strNext=new String(bbuf);

            lstServers.add(strNext);
          }

          socket.close();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnClose) {
        dispose();
      }
    }
  }

  class LoginAdminDialog extends Dialog
  implements ActionListener {
    volatile TextField tfServerName=new TextField();
    volatile TextField tfServerPort=new TextField();
    volatile TextField tfID=new TextField();
    volatile TextField tfAdmin=new TextField();
    volatile TextField tfPassword=new TextField();

    volatile Button btnLogin=new Button("Login");
    volatile Button btnCancel=new Button("Cancel");

    LoginAdminDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(5, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);
      pnlTemp.add(new Label("ID: "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("Administrator: "));
      pnlTemp.add(tfAdmin);
      pnlTemp.add(new Label("Password: "));
      pnlTemp.add(tfPassword);

      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnLogin);
      btnLogin.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnLogin) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strAdmin=tfAdmin.getText();
        if(strAdmin.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;

        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="Run Server";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strAdmin.length());
          dos.writeBytes(strAdmin);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();

          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          if(!strResponse.equals("Success")) {
            txtMain.append("\n\n");
            txtMain.append(strResponse);

            try {
              socket.close();
            }
            catch(Exception ex) {
            }

            return;
          }

          intLen=dis.readInt();
          bbuf=new byte[intLen];
          dis.readFully(bbuf);
          String strTree=new String(bbuf);

          rNO=StringUtility.createBIMRandomNumberObject(strTree);

          UserFrame.referenceBranches(rNO);

          user=new User(strAdmin, strPassword);
          user.setIsAdministrator(true);
          rCCR=new RandomCommunicatorClientReceiver(socket, dis, dos, user);
          rCCR.setMessageArea(txtMain);
          rCCT=new RandomCommunicatorClientTransmitter(socket, dis, dos, user);
          user.setClientReceiver(rCCR);
          user.setClientTransmitter(rCCT);
          rCCR.start();

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }

  class LoginUserDialog extends Dialog
  implements ActionListener {
    volatile TextField tfServerName=new TextField();
    volatile TextField tfServerPort=new TextField();
    volatile TextField tfID=new TextField();
    volatile TextField tfUser=new TextField();
    volatile TextField tfPassword=new TextField();

    volatile Button btnLogin=new Button("Login");
    volatile Button btnCancel=new Button("Cancel");

    LoginUserDialog(Frame parent, String strTitle) {
      super(parent, strTitle, true);

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(5, 2));
      pnlTemp.add(new Label("Server Name/IPAddress: "));
      pnlTemp.add(tfServerName);
      pnlTemp.add(new Label("Server Port Number: "));
      pnlTemp.add(tfServerPort);
      pnlTemp.add(new Label("ID: "));
      pnlTemp.add(tfID);
      pnlTemp.add(new Label("User: "));
      pnlTemp.add(tfUser);
      pnlTemp.add(new Label("Password: "));
      pnlTemp.add(tfPassword);

      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnLogin);
      btnLogin.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnLogin) {
        String strServerName=tfServerName.getText();
        if(strServerName.length()==0)
          return;

        String strServerPort=tfServerPort.getText();
        if(strServerPort.length()==0)
          return;
        int intServerPort=-1;
        try {
          intServerPort=Integer.parseInt(strServerPort);
        }
        catch(Exception ex) {
          return;
        }

        String strID=tfID.getText();
        if(strID.length()==0)
          return;

        for(int i=0;i<strID.length();i++) {
          char chrNext=strID.charAt(i);

          if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
            tfID.setText("Error. ID must be only letters or digits.");

            try {
              Thread.sleep(3000l);
            }
            catch(Exception ex) {
            }

            tfID.setText(strID);

            return;
          }
        }

        String strUser=tfUser.getText();
        if(strUser.length()==0)
          return;

        String strPassword=tfPassword.getText();
        if(strPassword.length()==0)
          return;

        try {
          Socket socket=new Socket(strServerName, intServerPort);
          DataInputStream dis=new DataInputStream(socket.getInputStream());
          DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

          String strCommand="Connect";
          dos.writeInt(strCommand.length());
          dos.writeBytes(strCommand);
          dos.flush();

          dos.writeInt(strID.length());
          dos.writeBytes(strID);
          dos.flush();

          dos.writeInt(strUser.length());
          dos.writeBytes(strUser);
          dos.flush();

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();

          int intLen=dis.readInt();
          byte bbuf[]=new byte[intLen];
          dis.readFully(bbuf);
          String strResponse=new String(bbuf);

          if(!strResponse.equals("Port")) {
            txtMain.append("\n\n");
            txtMain.append(strResponse);

            try {
              socket.close();
            }
            catch(Exception ex) {
            }

            return;
          }

          int intPort=dis.readInt();
 
          try {
            socket.close();
          }
          catch(Exception ex) {
          }

          socket=new Socket(strServerName, intPort);
          dis=new DataInputStream(socket.getInputStream());
          dos=new DataOutputStream(socket.getOutputStream());

          dos.writeInt(strPassword.length());
          dos.writeBytes(strPassword);
          dos.flush();

          int intResponse=dis.readInt();

          if(intResponse==SingleServer.LOGIN_FAIL) {
            int intLen2=dis.readInt();
            bbuf=new byte[intLen2];
            dis.readFully(bbuf);
            String strResponse2=new String(bbuf);

            txtMain.append("\n\n");
            txtMain.append(strResponse2);

            try {
              socket.close();
            }
            catch(Exception ex) {
            }

            return;
          }

          intLen=dis.readInt();
          bbuf=new byte[intLen];
          dis.readFully(bbuf);
          String strRoot=new String(bbuf);

          rNO=StringUtility.createBIMRandomNumberObject(strRoot);

          UserFrame.referenceBranches(rNO);


          dos.writeInt(strUser.length());
          dos.writeBytes(strUser);
          dos.flush();


          user=new User(strUser, strPassword);
          user.setIsAdministrator(false);
          rCCR=new RandomCommunicatorClientReceiver(socket, dis, dos, user);
          rCCR.setMessageArea(txtMain);
          rCCT=new RandomCommunicatorClientTransmitter(socket, dis, dos, user);
          user.setClientReceiver(rCCR);
          user.setClientTransmitter(rCCT);
          rCCR.start();

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }

  class RandomGenerateDialog extends Dialog
  implements ActionListener, ItemListener {
    volatile List lstRandoms=new List(5);
    volatile TextArea txtDetails=new TextArea(5, 100);
    volatile Button btnAscend=new Button("Ascend");
    volatile Button btnDescend=new Button("Descend");
    volatile Button btnRollRandom=new Button("Roll Random");
    volatile Button btnCancel=new Button("Cancel");
    volatile RandomNumberObject rNOLocal=null;

    RandomGenerateDialog(Frame parent, String strTitle) {
      super(parent, strTitle);

      rNOLocal=rNO;

//System.out.println("Root Size:"+rNOLocal.size());

      for(int i=0;i<rNOLocal.size();i++)
        lstRandoms.add(((RandomNumberObject)rNOLocal.elementAt(i)).getLeafName());

      add("North", new Label("Randoms"));
      Panel pnlTempZ=new Panel();
      pnlTempZ.setLayout(new GridLayout(2, 1));
      pnlTempZ.add(lstRandoms);
      lstRandoms.addItemListener(this);
      pnlTempZ.add(txtDetails);
      add("Center", pnlTempZ);
      add("West", btnDescend);
      btnDescend.addActionListener(this);
      add("East", btnAscend);
      btnAscend.addActionListener(this);
      Panel pnlTemp=new Panel();
      pnlTemp.add(btnRollRandom);
      btnRollRandom.addActionListener(this);
      pnlTemp.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public void itemStateChanged(ItemEvent ie) {
      int intIndex=lstRandoms.getSelectedIndex();
      if(intIndex==-1)
        return;

      txtDetails.setText(((RandomNumberObject)rNO.elementAt(intIndex)).getLeafDescription());
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAscend) {
        int intIndex=lstRandoms.getSelectedIndex();
        if(intIndex==-1)
          return;

        rNOLocal=(RandomNumberObject)rNOLocal.elementAt(intIndex);

//System.out.println("ascend: "+rNOLocal.size());

        lstRandoms.removeAll();
        for(int i=0;i<rNOLocal.size();i++) {
          RandomNumberObject nextRNO=(RandomNumberObject)rNOLocal.elementAt(i);
          lstRandoms.add(nextRNO.getLeafName());
        }
      }
      else if(evSource==btnDescend) {
        if(rNOLocal.isRoot())
          return;

        rNOLocal=rNOLocal.getLeafsBranch();

        lstRandoms.removeAll();
        for(int i=0;i<rNOLocal.size();i++) {
          RandomNumberObject nextRNO=(RandomNumberObject)rNOLocal.elementAt(i);
          lstRandoms.add(nextRNO.getLeafName());
        }
      }
      else if(evSource==btnRollRandom) {
        int intIndex=lstRandoms.getSelectedIndex();
        if(intIndex==-1)
          return;

        try {
          rCCT.dos.writeInt(RandomCommunicatorServerReceiver.GENERATE_RANDOM);
          rCCT.dos.flush();

          RandomNumberObject rBranch=rNOLocal;

          Vector vecBranchIndices=new Vector();
          vecBranchIndices.addElement(new Integer(intIndex));
          while(true) {
            if(rBranch.isRoot())
              break;

            vecBranchIndices.addElement(new Integer(rBranch.getLeafIndex()));

            rBranch=rBranch.getLeafsBranch();
          }

          rCCT.dos.writeInt(vecBranchIndices.size());
          for(int i=vecBranchIndices.size()-1;i>=0;i--)
            rCCT.dos.writeInt(((Integer)vecBranchIndices.elementAt(i)).intValue());
          rCCT.dos.flush();

          dispose();
        }
        catch(Exception ex) {
        }
      }
      else if(evSource==btnCancel) {
        dispose();
      }
    }
  }
}