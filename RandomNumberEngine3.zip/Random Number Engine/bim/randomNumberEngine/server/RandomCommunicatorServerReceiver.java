package bim.randomNumberEngine.server;

import bim.randomNumberEngine.client.RandomCommunicatorClientReceiver;
import bim.randomNumberEngine.data.User;
import bim.randomNumberEngine.data.RandomNumberObject;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.io.*;
import java.util.Date;

public class RandomCommunicatorServerReceiver extends Thread {
  public static int GENERATE_RANDOM=0;
  public static int CHAT_MESSAGE=1;

  volatile boolean keepAlive=true;

  volatile Socket clientSocket;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;

  volatile User user;

  volatile SingleServer server;

  public RandomCommunicatorServerReceiver(Socket clientSocket, DataInputStream dis, DataOutputStream dos, User user, SingleServer server) {
    this.clientSocket=clientSocket;
    this.dis=dis;
    this.dos=dos;
    this.user=user;
    this.server=server;
  }

  public Socket getSocket() {
    return clientSocket;
  }

  public void setSocket(Socket clientSocket) {
    this.clientSocket=clientSocket;
  }

  public DataInputStream getInputStream() {
    return dis;
  }

  public void setInputStream(DataInputStream dis) {
    this.dis=dis;
  }

  public DataOutputStream getOutputStream() {
    return dos;
  }

  public void setOutputStream(DataOutputStream dos) {
    this.dos=dos;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user=user;
  }

  public SingleServer getServer() {
    return server;
  }

  public void setServer(SingleServer server) {
    this.server=server;
  }

  public void run() {
    try {
      while(server.keepAlive & keepAlive) {
        int intCode=dis.readInt();

        if(intCode==GENERATE_RANDOM) {
          int intBranchDepth=dis.readInt();

          RandomNumberObject rNO=server.rNS.getRoot();

          StringBuffer sBPath=new StringBuffer();
          sBPath.append("\n\n");
          sBPath.append(rNO.getLeafName());

          for(int i=0;i<intBranchDepth;i++) {
            rNO=(RandomNumberObject)rNO.elementAt(dis.readInt());
            sBPath.append("\n"+rNO.getLeafName());
          }

          sBPath.append("\n\n");
          sBPath.append(new Date().toString());

          double dblRandom=rNO.generateRandom();

          String strRandom=String.valueOf(dblRandom);

          if(rNO.getRandomNumberType()==RandomNumberObject.RANDOM_NUMBER_ROUNDED)
            strRandom=String.valueOf(new Double(dblRandom).intValue());

          server.transmitString(user.getUserName()+" rolled a "+strRandom+sBPath.toString(), RandomCommunicatorClientReceiver.GENERATE_RANDOM);
        }
        else if(intCode==CHAT_MESSAGE) {
          int intMessageLen=dis.readInt();
          byte bbuf[]=new byte[intMessageLen];
          dis.readFully(bbuf);
          String strMessage=new String(bbuf);

          server.transmitString(user.getUserName()+" says, \""+strMessage+"\"", RandomCommunicatorClientReceiver.CHAT_MESSAGE);
        }
      }
    }
    catch(Exception ex) {
      if((ex instanceof SocketException) || (ex instanceof EOFException)) {
      }
      else {
        ex.printStackTrace();
      }
    }

    try {
      clientSocket.close();
    }
    catch(Exception ex) {
    }

//System.out.println("before admin check: "+user.getUserName());
    if(user.isAdministrator()) {
//System.out.println("is administrator");

      server.keepAlive=false;
      try {
        server.interrupt();
      }
      catch(Exception ex) {
      }

//System.out.println("Users: "+server.vecUsers.size());

      for(int i=0;i<server.vecUsers.size();i++) {
        User userNext=(User)server.vecUsers.elementAt(i);

//System.out.println(userNext.getUserName());

        RandomCommunicatorServerReceiver sRNext=userNext.getServerReceiver();

        sRNext.keepAlive=false;

        try {
          sRNext.clientSocket.close();
        }
        catch(Exception ex) {
        }

        try {
          sRNext.interrupt();

//System.out.println("interrupt successful");
        }
        catch(Exception ex) {
//System.out.println("interrupt not successful");
//ex.printStackTrace();
        }
      }
    }
  }
}