package bim.randomNumberEngine.server;

import bim.randomNumberEngine.data.User;
import bim.randomNumberEngine.data.StringUtility;
import bim.randomNumberEngine.data.RandomNumberServer;
import bim.randomNumberEngine.data.RandomNumberObject;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.*;
import java.util.Hashtable;

public class MainServer {
  volatile static Object SYNC_ALL=new Object();

  volatile static boolean keepAlive=true;

  volatile static Hashtable hashPorts=new Hashtable();

  public static void main(String args[]) {
    if(args.length!=1) {
      System.out.println("Usage:");
      System.out.println("  java bim.RandomNumberEngine.server.MainServer <port number>");
      return;
    }

    int intPort=-1;
    try {
      intPort=Integer.parseInt(args[0]);
    }
    catch(Exception ex) {
      System.out.println("Invalid port number. Argument must be an integer.");
      return;
    }

    try {
      ServerSocket serverSock=new ServerSocket(intPort);

      while(true) {
        Socket socket=serverSock.accept();

        DataInputStream dis=new DataInputStream(socket.getInputStream());
        DataOutputStream dos=new DataOutputStream(socket.getOutputStream());

        int intCommandLen=dis.readInt();
        byte bbuf[]=new byte[intCommandLen];
        dis.readFully(bbuf);
        String strCommand=new String(bbuf);

        if(strCommand.equalsIgnoreCase("New Server")) {
          MainServer.createNewServer(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("Copy Server")) {
          MainServer.copyServer(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("Delete Server")) {
          MainServer.deleteServer(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("Load Server")) {
          MainServer.loadServer(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("Run Server")) {
          MainServer.runServer(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("Connect")) {
          MainServer.connect(socket, dis, dos);
        }
        else if(strCommand.equalsIgnoreCase("List Servers")) {
          MainServer.listServers(socket, dis, dos);
        }

        if(strCommand.equalsIgnoreCase("Run Server")) {
        }
        else {
          try {
            socket.close();
          }
          catch(Exception ex) {
          }
        }
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public static void createNewServer(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intAdminLen=dis.readInt();
    bbuf=new byte[intAdminLen];
    dis.readFully(bbuf);
    String strAdministrator=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);

    int intUserPasswordLen=dis.readInt();
    bbuf=new byte[intUserPasswordLen];
    dis.readFully(bbuf);
    String strUserPassword=new String(bbuf);

    int intTreeLen=dis.readInt();
    bbuf=new byte[intTreeLen];
    dis.readFully(bbuf);
    String strTree=new String(bbuf);

//    int intLenLen=Integer.parseInt(strTree.substring(0, 1));
//    strTree=strTree.substring(1+intLenLen);

//System.out.println(strTree);


    if(strID.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    RandomNumberObject rNO=StringUtility.createBIMRandomNumberObject(strTree);

    RandomNumberServer rNS=new RandomNumberServer(strID, strAdministrator, strPassword, strUserPassword);
    rNS.setRoot(rNO);

    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(fileServer.exists()) {
        String strResponse="Server ID already exists. Unable to create server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to create server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if((intIDLen+intAdminLen+intPasswordLen+intUserPasswordLen+intTreeLen)>RandomNumberServer.MAXIMUM_SERVER_LENGTH) {
      String strResponse="Server is too big to be saved. Unable to create server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    try {
      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("servers"+System.getProperty("file.separator")+strID)));
      oos.writeObject(rNS);
      oos.close();

      String strResponse="New server created. ID: "+strID;
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();
    }
    catch(Exception ex) {
      String strResponse="Error serializing data. Unable to create server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void copyServer(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intAdminLen=dis.readInt();
    bbuf=new byte[intAdminLen];
    dis.readFully(bbuf);
    String strAdministrator=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);


    int intIDLen2=dis.readInt();
    bbuf=new byte[intIDLen2];
    dis.readFully(bbuf);
    String strID2=new String(bbuf);

    int intAdminLen2=dis.readInt();
    bbuf=new byte[intAdminLen2];
    dis.readFully(bbuf);
    String strAdministrator2=new String(bbuf);

    int intPasswordLen2=dis.readInt();
    bbuf=new byte[intPasswordLen2];
    dis.readFully(bbuf);
    String strPassword2=new String(bbuf);

    int intUserPasswordLen2=dis.readInt();
    bbuf=new byte[intUserPasswordLen2];
    dis.readFully(bbuf);
    String strUserPassword2=new String(bbuf);

    if(strID.length()==0 || strID2.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID) || MainServer.isNotLetterOrDigit(strID2)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(!fileServer.exists()) {
        String strResponse="Server ID doesn't exist. Unable to copy server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileServer));
      RandomNumberServer rNS=(RandomNumberServer)ois.readObject();
      ois.close();

      if(!rNS.getAdministrator().equals(strAdministrator)) {
        String strResponse="Server administrator doesn't match. Unable to copy server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      if(!rNS.getPassword().equals(strPassword)) {
        String strResponse="Server password doesn't match. Unable to copy server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      RandomNumberObject rNO=rNS.getRoot();
      int rNOLength=StringUtility.createBIMString(rNO).length();

      if((intIDLen2+intAdminLen2+intPasswordLen2+intUserPasswordLen2+rNOLength)>RandomNumberServer.MAXIMUM_SERVER_LENGTH) {
        String strResponse="Server is too big to be saved. Unable to copy server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      rNS.setID(strID2);
      rNS.setAdministrator(strAdministrator2);
      rNS.setPassword(strPassword2);
      rNS.setUserPassword(strUserPassword2);

      File fileServer2=new File("servers"+System.getProperty("file.separator")+strID2);

      if(fileServer2.exists()) {
        String strResponse="Server ID already exists. Unable to copy server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileServer2));
      oos.writeObject(rNS);
      oos.close();

      String strResponse="Server copied successfully. ID of source: "+strID+" ID of destination: "+strID2;
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to copy server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void deleteServer(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intAdminLen=dis.readInt();
    bbuf=new byte[intAdminLen];
    dis.readFully(bbuf);
    String strAdministrator=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);

    if(strID.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(!fileServer.exists()) {
        String strResponse="Server ID doesn't exist. Unable to delete server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileServer));
      RandomNumberServer rNS=(RandomNumberServer)ois.readObject();
      ois.close();

      if(!rNS.getAdministrator().equals(strAdministrator)) {
        String strResponse="Server administrator doesn't match. Unable to delete server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      if(!rNS.getPassword().equals(strPassword)) {
        String strResponse="Server password doesn't match. Unable to delete server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      fileServer.delete();

      String strResponse="Server deleted successfully. ID : "+strID;
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to delete server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void loadServer(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intAdminLen=dis.readInt();
    bbuf=new byte[intAdminLen];
    dis.readFully(bbuf);
    String strAdministrator=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);

    if(strID.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(!fileServer.exists()) {
        String strResponse="Server ID doesn't exist. Unable to load server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileServer));
      RandomNumberServer rNS=(RandomNumberServer)ois.readObject();
      ois.close();

      if(!rNS.getAdministrator().equals(strAdministrator)) {
        String strResponse="Server administrator doesn't match. Unable to load server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      if(!rNS.getPassword().equals(strPassword)) {
        String strResponse="Server password doesn't match. Unable to load server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      RandomNumberObject rNO=rNS.getRoot();
      String strRNO=StringUtility.createBIMString(rNO);

      String strResponse="Success";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      dos.writeInt(strRNO.length());
      dos.writeBytes(strRNO);
      dos.flush();
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to copy server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void runServer(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intAdminLen=dis.readInt();
    bbuf=new byte[intAdminLen];
    dis.readFully(bbuf);
    String strAdministrator=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);

    if(strID.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(!fileServer.exists()) {
        String strResponse="Server ID doesn't exist. Unable to start server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileServer));
      RandomNumberServer rNS=(RandomNumberServer)ois.readObject();
      ois.close();

      if(!rNS.getAdministrator().equals(strAdministrator)) {
        String strResponse="Server administrator doesn't match. Unable to start server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      if(!rNS.getPassword().equals(strPassword)) {
        String strResponse="Server password doesn't match. Unable to start server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      String strResponse="Success";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      SingleServer server=new SingleServer(rNS);
      server.start();


      while(!server.blnPortOpened) {
        try {
          Thread.sleep(100l);
        }
        catch(Exception ex) {
        }
      }

      hashPorts.put(strID, new Integer(server.serverSocket.getLocalPort()));



      RandomNumberObject rNO=rNS.getRoot();
      String strRNO=StringUtility.createBIMString(rNO);
      dos.writeInt(strRNO.length());
      dos.writeBytes(strRNO);
      dos.flush();

      User user=new User(strAdministrator, strPassword);
      user.setIsAdministrator(true);
      RandomCommunicatorServerReceiver rCSR=new RandomCommunicatorServerReceiver(socket, dis, dos, user, server);
      user.setServerReceiver(rCSR);
      user.setServerTransmitter(new RandomCommunicatorServerTransmitter(socket, dis, dos, user));
      server.vecUsers.addElement(user);
      rCSR.start();
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to start server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void connect(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    int intIDLen=dis.readInt();
    byte bbuf[]=new byte[intIDLen];
    dis.readFully(bbuf);
    String strID=new String(bbuf);

    int intUserLen=dis.readInt();
    bbuf=new byte[intUserLen];
    dis.readFully(bbuf);
    String strUser=new String(bbuf);

    int intPasswordLen=dis.readInt();
    bbuf=new byte[intPasswordLen];
    dis.readFully(bbuf);
    String strPassword=new String(bbuf);

    if(strID.length()==0) {
      String strResponse="Error. ID can't be length of 0.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }

    if(MainServer.isNotLetterOrDigit(strID)) {
      String strResponse="Error. ID must be only letters or digits.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }


    try {
      File fileServer=new File("servers"+System.getProperty("file.separator")+strID);

      if(!fileServer.exists()) {
        String strResponse="Server ID doesn't exist. Unable to connect to server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileServer));
      RandomNumberServer rNS=(RandomNumberServer)ois.readObject();
      ois.close();

      if(rNS.getAdministrator().equals(strUser)) {
        String strResponse="Server administrator's name used. Use admin login to start server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      if(!rNS.getUserPassword().equals(strPassword)) {
        String strResponse="Server password doesn't match. Unable to connect to server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      Object objPort=hashPorts.get(strID);
      if(objPort==null) {
        String strResponse="Server hasn't been initialized by administrator. Unable to connect to server.";
        dos.writeInt(strResponse.length());
        dos.writeBytes(strResponse);
        dos.flush();

        return;
      }

      int intPort=((Integer)objPort).intValue();

      String strResponse="Port";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      dos.writeInt(intPort);
      dos.flush();
    }
    catch(Exception ex) {
      String strResponse="Error with file system. Unable to connect to server.";
      dos.writeInt(strResponse.length());
      dos.writeBytes(strResponse);
      dos.flush();

      return;
    }
  }

  public static void listServers(Socket socket, DataInputStream dis, DataOutputStream dos) throws Exception {
    File fileServer=new File("servers");

    String strServers[]=fileServer.list();

    dos.writeInt(strServers.length);

    for(int i=0;i<strServers.length;i++) {
      dos.writeInt(strServers[i].length());
      dos.writeBytes(strServers[i]);
    }

    dos.flush();
  }

  public static boolean isNotLetterOrDigit(String strID) {
    for(int i=0;i<strID.length();i++) {
      char chrNext=strID.charAt(i);

      if(!Character.isLetter(chrNext) & !Character.isDigit(chrNext)) {
        return true;
      }
    }

    return false;
  }
}