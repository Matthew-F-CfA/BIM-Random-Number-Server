package bim.randomNumberEngine.server;

import bim.randomNumberEngine.data.StringUtility;
import bim.randomNumberEngine.data.RandomNumberServer;
import bim.randomNumberEngine.data.RandomNumberObject;
import bim.randomNumberEngine.data.User;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.Vector;

public class SingleServer extends Thread {
  public static int LOGIN_SUCCESSFUL=0;
  public static int LOGIN_FAIL=1;

  volatile boolean keepAlive=true;

  volatile RandomNumberServer rNS;

//  MainServer mainServer;

  volatile Vector vecUsers=new Vector();

  volatile ServerSocket serverSocket;
  volatile boolean blnPortOpened=false;

  SingleServer() {
    super();
  }

  SingleServer(RandomNumberServer rNS) {
    super();
//    this.mainServer=mainServer;
    this.rNS=rNS;
  }

  public Vector getUsers() {
    return vecUsers;
  }

  public void setUsers(Vector vecUsers) {
    this.vecUsers=vecUsers;
  }

  public void transmitString(String strStr, int intCode) {
synchronized(MainServer.SYNC_ALL) {
    for(int i=0;i<vecUsers.size();i++) {
      try {
        User user=(User)vecUsers.elementAt(i);
        RandomCommunicatorServerTransmitter rCST=user.getServerTransmitter();
        DataOutputStream dos=rCST.getOutputStream();

        dos.writeInt(intCode);
        dos.writeInt(strStr.length());
        dos.writeBytes(strStr);
        dos.flush();
      }
      catch(Exception ex) {
      }
    }
}
  }

  public void run() {
    try {
      serverSocket=new ServerSocket(0);

      blnPortOpened=true;

      while(MainServer.keepAlive & keepAlive) {
        Socket clientSocket=serverSocket.accept();

        try {
          DataInputStream dis=new DataInputStream(clientSocket.getInputStream());
          DataOutputStream dos=new DataOutputStream(clientSocket.getOutputStream());

          int intPasswordLen=dis.readInt();
          byte bbuf[]=new byte[intPasswordLen];
          dis.readFully(bbuf);
          String strPassword=new String(bbuf);

          if(!strPassword.equals(rNS.getUserPassword())) {
            dos.writeInt(LOGIN_FAIL);

            String strResponse="Incorrect password.";
            dos.writeInt(strResponse.length());
            dos.writeBytes(strResponse);
            dos.flush();

            clientSocket.close();
            continue;
          }

          dos.writeInt(LOGIN_SUCCESSFUL);

          RandomNumberObject rNO=rNS.getRoot();
          String strRNO=StringUtility.createBIMString(rNO);
          dos.writeInt(strRNO.length());
          dos.writeBytes(strRNO);
          dos.flush();

          int intNameLen=dis.readInt();
          bbuf=new byte[intNameLen];
          dis.readFully(bbuf);
          String strName=new String(bbuf);

          User user=new User(strName, strPassword);
          RandomCommunicatorServerReceiver rCSR=new RandomCommunicatorServerReceiver(clientSocket, dis, dos, user, this);
          user.setServerReceiver(rCSR);
          user.setServerTransmitter(new RandomCommunicatorServerTransmitter(clientSocket, dis, dos, user));
          vecUsers.addElement(user);
          rCSR.start();
        }
        catch(Exception ex) {
        }
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}