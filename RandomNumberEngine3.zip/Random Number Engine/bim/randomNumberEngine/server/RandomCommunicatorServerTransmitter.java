package bim.randomNumberEngine.server;

import bim.randomNumberEngine.data.User;
import java.net.Socket;
import java.io.*;

public class RandomCommunicatorServerTransmitter {
  volatile Socket clientSocket;
  volatile DataInputStream dis;
  volatile DataOutputStream dos;

  volatile User user;

  public RandomCommunicatorServerTransmitter(Socket clientSocket, DataInputStream dis, DataOutputStream dos, User user) {
    this.clientSocket=clientSocket;
    this.dis=dis;
    this.dos=dos;
    this.user=user;
  }

  public Socket getSocket() {
    return clientSocket;
  }

  public void setSocket(Socket clientSocket) {
    this.clientSocket=clientSocket;
  }

  public DataInputStream getInputStream() {
    return dis;
  }

  public void setInputStream(DataInputStream dis) {
    this.dis=dis;
  }

  public DataOutputStream getOutputStream() {
    return dos;
  }

  public void setOutputStream(DataOutputStream dos) {
    this.dos=dos;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user=user;
  }
}